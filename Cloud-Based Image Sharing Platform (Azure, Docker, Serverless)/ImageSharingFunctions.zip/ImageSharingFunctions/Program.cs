using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ImageSharingFunctions
{
    public class Program
    {
        public static void Main()
        {
            var host = new HostBuilder()
                .ConfigureFunctionsWorkerDefaults()  // sets up isolated worker, bindings, logging
                .ConfigureServices(services =>
                {
                    // add DI services if you ever need them
                })
                .Build();

            host.Run();
        }
    }
}