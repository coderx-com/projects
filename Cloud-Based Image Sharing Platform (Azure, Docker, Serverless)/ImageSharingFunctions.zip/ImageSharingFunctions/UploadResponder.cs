using System;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ImageSharingFunctions
{
    public class UploadResponder
    {
        private readonly ILogger _logger;
        private readonly QueueClient _approvalQueue;

        public UploadResponder(IConfiguration config, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<UploadResponder>();

            // This MUST match your app setting name in the Function App:
            // QueueStorageConnectionString = DefaultEndpointsProtocol=...
            var queueConn = config["QueueStorageConnectionString"];
            if (string.IsNullOrWhiteSpace(queueConn))
            {
                throw new InvalidOperationException(
                    "QueueStorageConnectionString setting is missing.");
            }

            _approvalQueue = new QueueClient(queueConn, "approval-requests");
            _approvalQueue.CreateIfNotExists();
        }

        // Triggered when a new blob is written to the "images" container
        [Function("UploadResponder")]
        public async Task Run(
            [BlobTrigger("images/{name}", Connection = "AzureWebJobsStorage")] byte[] imageBytes,
            string name)
        {
            _logger.LogInformation(
                "UploadResponder triggered for blob {Name}, size = {Size} bytes",
                name, imageBytes.Length);

            // Very small message, just metadata
            var msg = new
            {
                BlobName = name,
                SizeBytes = imageBytes.Length,
                UploadedOnUtc = DateTime.UtcNow
            };

            string json = JsonSerializer.Serialize(msg);
            string base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));

            await _approvalQueue.SendMessageAsync(base64);

            _logger.LogInformation("Message pushed to 'approval-requests' queue.");
        }
    }
}
