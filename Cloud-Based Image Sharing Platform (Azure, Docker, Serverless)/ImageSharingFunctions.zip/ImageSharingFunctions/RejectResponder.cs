using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ImageSharingWithCloud.Models;
using Microsoft.Azure.Functions.Worker.Extensions.Storage;

namespace ImageSharingFunctions
{
    /// <summary>
    /// Triggered when an image is rejected by the MVC application.  Decodes
    /// the Base64 payload and deletes the associated blob from storage.
    /// </summary>
    public class RejectResponder
    {
        private readonly ILogger _logger;
        private readonly BlobContainerClient _blobContainer;

        public RejectResponder(ILoggerFactory loggerFactory, BlobServiceClient blobService)
        {
            _logger = loggerFactory.CreateLogger<RejectResponder>();
            _blobContainer = blobService.GetBlobContainerClient("images");
        }

        [Function(nameof(RejectResponder))]
        public async Task Run([
            QueueTrigger("rejected-images", Connection = "QueueStorageConnectionString")] string base64Message)
        {
            _logger.LogInformation("RejectResponder triggered");
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(base64Message));
            var image = JsonConvert.DeserializeObject<Image>(json);
            if (image == null)
            {
                _logger.LogError("Failed to deserialize image from rejected message");
                return;
            }
            var blobName = $"image-{image.Id}.jpg";
            _logger.LogInformation("Deleting blob {blob}", blobName);
            await _blobContainer.DeleteBlobIfExistsAsync(blobName);
        }
    }
}