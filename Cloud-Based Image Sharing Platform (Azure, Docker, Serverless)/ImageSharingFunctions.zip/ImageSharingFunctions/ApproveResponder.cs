using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using ImageSharingWithCloud.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Functions.Worker.Extensions.Storage;

namespace ImageSharingFunctions
{
    /// <summary>
    /// Triggered when an image is approved by the MVC application.  Decodes
    /// the Base64 payload, deserializes the image, sets the approval flags
    /// and writes the entity to Cosmos DB.
    /// </summary>
    public class ApproveResponder
    {
        private readonly ILogger _logger;
        private readonly CosmosClient _cosmos;

        public ApproveResponder(ILoggerFactory loggerFactory, CosmosClient cosmosClient)
        {
            _logger = loggerFactory.CreateLogger<ApproveResponder>();
            _cosmos = cosmosClient;
        }

        [Function(nameof(ApproveResponder))]
        public async Task Run([
            QueueTrigger("approved-images", Connection = "QueueStorageConnectionString")] string base64Message)
        {
            _logger.LogInformation("ApproveResponder triggered");
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(base64Message));
            var image = JsonConvert.DeserializeObject<Image>(json);
            if (image == null)
            {
                _logger.LogError("Failed to deserialize image from approved message");
                return;
            }
            image.Approved = true;
            image.Valid = true;
            // Write to Cosmos DB.  Database and container names are fixed per the assignment.
            var container = _cosmos.GetContainer("imagesharing", "images");
            await container.CreateItemAsync(image, new PartitionKey(image.UserId));
            _logger.LogInformation("Image {id} approved and stored in Cosmos DB", image.Id);
        }
    }
}